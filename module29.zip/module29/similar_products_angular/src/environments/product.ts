
prodId:String;
prodName:String;
 prodCategory:String;
 price:Number;
discount:Number;
validTime:String;
promoCode:String;
viewsCount:Number;
qty:Number;

